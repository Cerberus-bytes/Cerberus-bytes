<?php
	// You'd put this code at the top of any "protected" page you create
	// Always start this first
session_start();

if ( isset( $_SESSION['LoggedIn'] ) ) {
   	// Grab user data from the database using the user_id
	// Let them access the "logged in only" pages
} else {
 	// Redirect them to the login page
header("Location: index.php");
}
?>
<html>
<head>
<title>System Tools</title>
<link rel="stylesheet" href="css/styles.css">
</head>

<body>
	<div class="container">
		<div class="inner">
			<?php
				$session_destroy();
				echo "<p><a href='index.php'>Click to Log In Again</a>";
			?>

		</div>
	</div>
</body>
</html>