<?php
	// You'd put this code at the top of any "protected" page you create
	// Always start this first
session_start();

if ( isset( $_SESSION['LoggedIn'] ) ) {
   	// Grab user data from the database using the user_id
	// Let them access the "logged in only" pages
} else {
 	// Redirect them to the login page
header("Location: index.php");
}
?>
<html>
<head>
<title>System Tools - Command</title>
<link rel="stylesheet" href="css/styles.css">
</head>

<body>
	<div class="container">
		<div class="inner">
		
			<?php
				//if ($_SESSION['LoggedIn']) {
				if (isset($_SESSION['LoggedIn'])) {
					echo "You are currently logged in<p>";
				}
				else
				{
					
				}
			?>
		
			<form method="post" action="command.php">
				<strong>Run Command:</strong><br>
				<input type="radio" name="radio" value="ls -l" checked="checked">List Files<br />
				<input type="radio" name="radio" value="du -h">Disk Usage<br />
				<input type="radio" name="radio" value="df -h">Disk Free<br />
				<p>
				<input type="submit" name="submit" value="Run">
			</form>
			
			<?php
			
				//if ($_SESSION['LoggedIn']) {
				if (isset($_SESSION['LoggedIn'])) {
					if (isset($_POST['submit'])) {
					if(isset($_POST['radio']))
						{
							echo "You have selected: ".$_POST['radio'] . "<br />";
							$my_cmd = $_POST['radio'];
							//echo $my_cmd;
							$output = shell_exec($my_cmd);
							echo "<pre>";
							print $output;
							echo "</pre>";
						}
					}
					echo "<p><a href='login.php'>Return to the menu.</a>";
				}
				else
				{
					echo "You need to be logged in to use this system.";
					echo "<p><a href='index.php'>Click to Log In Again</a>";
				}
			?>
			
		</div>
	</div>
</body>
</html>