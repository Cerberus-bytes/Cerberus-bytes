<?php
	// You'd put this code at the top of any "protected" page you create
	// Always start this first
session_start();

if ( isset( $_SESSION['LoggedIn'] ) ) {
   	// Grab user data from the database using the user_id
	// Let them access the "logged in only" pages
} else {
 	// Redirect them to the login page
//header("Location: index.php");
}
?>

<html>
<head>
<title>System Tools</title>
<link rel="stylesheet" href="css/styles.css">
</head>

<body>
	<div class="container">
		<div class="inner">
			<?php
				$username = $_POST['username'];
				$password = $_POST['password'];
				
				if ($username == 'admin' && $password == 'happy') {
					$_SESSION['LoggedIn']=$username;
				}
				else
				{
					//$_SESSION['NotLoggedIn'];
					echo "Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''' at line 1";
					//echo "Does this look right to you?";
				}
				
				if ($_SESSION['LoggedIn']) {
					echo "You are currently logged in<p>";
					echo "<div class=\"menu-system\">";
					echo "<h3>System Tools</h3>";
					echo "<a href='command.php'>Command</a><p>";
					echo "</div>";
					echo "<p><a href='logout.php'>Click to Logout</a>";
				}
				else
				{
					//echo "Invalid Username or Password";
					//echo "<p><a href='index.php'>Click to Log In Again</a>";
				}
			?>
			
		</div>
	</div>
</body>
</html>