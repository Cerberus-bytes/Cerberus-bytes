<!DOCTYPE html>
<html>
<head>
<title>System Tools</title>
<link rel="stylesheet" href="css/styles.css">
</head>

<body>
	<div class="container">
		<div class="inner">
			<h2>Information Systems Login</h2>
			<form action="login.php" method="post">
				Username:<br>
				<input type="text" name="username" value=""><p>
				Password:<br>
				<input type="password" name="password" value=""><p>
				<input type="submit" value="Submit">
			</form>

		</div>
	</div>
</body>
</html>